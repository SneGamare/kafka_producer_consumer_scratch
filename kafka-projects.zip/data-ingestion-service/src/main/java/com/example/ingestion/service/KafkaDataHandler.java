package com.example.ingestion.service;

import com.example.ingestion.entity.RecordEntity;
import com.example.ingestion.repository.RecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaDataHandler {

    @Autowired
    private RecordRepository recordRepository;

    @KafkaListener(topics = "test-topic", groupId = "db-group")
    public void consumeAndSave(String message) {
        RecordEntity entity = new RecordEntity(message);
        recordRepository.save(entity);
    }
}