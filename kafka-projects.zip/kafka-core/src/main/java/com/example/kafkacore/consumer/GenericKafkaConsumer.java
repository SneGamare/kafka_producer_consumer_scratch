package com.example.kafkacore.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class GenericKafkaConsumer {

    @KafkaListener(topics = "test-topic", groupId = "default-group")
    public void consume(String message) {
        System.out.println("Consumed message: " + message);
    }
}